# aws-thumbnail-s3-lambda
Sample Code for generate a thumbnail on s3 using lambda and python
